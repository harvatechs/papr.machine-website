Papr.Machine — Free Windows Demo Package
Version: 1.0.0 (Trial / Evaluation Build)
By: Tilak Infotech (https://papr.machine)

Thank you for downloading the Papr.Machine evaluation build!

Quick Start Instructions:
1. Extract all files into a local folder.
2. Launch 'PaprMachineLauncher.exe' (requires Windows 10/11 64-bit).
3. Choose 'Admin Panel' to configure sample pricing rules and printer pairing.
4. Choose 'Display' to launch the live customer kiosk screen.

Privacy & Safety:
- No account or credit card required.
- All evaluation sessions run completely locally on your computer.
- No data leaves your machine.

For commercial licenses, custom kiosk enclosures, or franchise queries:
Email: contact@tilakinfotech.com
Website: https://papr.machine
